<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from user where id='$did'");
            header("Location:add_admin.php");
             }
?> 

<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>
<body bgcolor="lavender">
<img src="images/university.jpg" width="1400" height="300">
<body>

      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_faculty.php">Add Faculty </a>
         </td>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

		<td class="menu">
            <a class="linkk" href="contact_admin.php">Contact Admin </a>
         </td>

     </tr>
</table>
</body>


<html>
  <head>
    <style>
   body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 0px black solid;
                 height: 420px; width: 410px;
                }
   .center {
    margin: auto;
    }
         </style>
  </head>

<body bgcolor="brown">
    <body>

 <table border="1" width= "700" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "20" align= "center" style="background-color: white"> Admin Message </td> </tr>
   <tr> <td align="center"> SL No </td> <td align="center"> Name </td>  <td align="center"> Contact </td> <td align="center"> Email </td> <td align="center"> Description </td></tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from contact_admin ");
   while($user=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td> <?php echo $i;?></td>
   <td> <?php echo $user['name']; ?> </td>
   
   <td> <?php echo $user['contact']; ?> </td>
   <td> <?php echo $user['email']; ?> </td>
   <td> <?php echo $user['description']; ?> </td>
  <td>
  <?php
   echo"<a href=\"javascript:delete_Admin Message(id=$Admin[id])\"> Delete </a>";
   ?>
 </td>  
 </tr>
   
 </tr>
 
  <?php $i++;} ?>
 
 </table>


<script>
	function validateForm(){var name = document.add_admin.name.value;
	
		var email = document.add_admin.email.value;
	
	if(name==""){alert("Please enter your name."); return false;}
	if(contact==""){alert("Please enter your contact."); return false;}
	if(email==""){alert("Please enter your email."); return false;}
	
						}
</script>
 <script language="Javascript">
   function delete_message(id){
              var msg= confirm('Are you sure you want to delete this admin?');
            if (msg){
                 window.location="add_student.php?did="+id;  
                }   
           }
 </script>
   </div>
     </body>
</html>

  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>