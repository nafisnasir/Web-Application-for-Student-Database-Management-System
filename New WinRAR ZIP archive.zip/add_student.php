<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from user where id='$did'");
            header("Location:add_student.php");
             }
?> 

<html>
  <head>
    <style>
   body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 3px black solid;
                 height: 410px; width: 400px;
                }
   .center {
    margin: auto;
    }
         </style>
  </head>

<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>
<body bgcolor="moccasin">
<img src="images/student.png" width="1400" height="300">
<body>

      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_faculty.php">Add Faculty </a>
         </td>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

		<td class="menu">
            <a class="linkk" href="contact_admin.php">Contact Admin </a>
         </td>

     </tr>
</table>
</body>




    <body>

   <div class="center">
    <?php if($e){$_SESSION['edit']=$e;
                 $n=mysql_query("select * from user where id='$e'");
                 $edit=mysql_fetch_array($n);}
    ?>
      
 <form action="action.php" method="post" name="add_student" onsubmit="return(validateForm());">
<?php
if ($_SESSION['msg'])
    {
     echo $_SESSION['msg'];
     $_SESSION['msg']="";
     } 
?>
   <table border="0" width= "400" height= "200" align= "center">
	<tr>
          <td colspan= "2" align= "center" style= "background-color: grey"> <h1> Add Student </h1> </td>
	</tr>
	<tr>
           <td> Name: </td>
           <td> <input type="text" name="name" value="<?php if($e){echo $edit['name'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
           <td> User ID: </td>
           <td> <input type="text" name="user_id" value="<?php if($e){echo $edit['user_id'];}else{echo "";}?>"> </td>
	</tr>
        <tr>
           <td> Password: </td>
           <td> <input type="password" name="password" value="<?php if($e){echo $edit['password'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
           <td> Confirm Password: </td>
           <td> <input type="password" name="confirm_password" value="<?php if($e){echo $edit['confirm_password'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Gender: </td>
            <td> Male<input type="radio" name="gender" value="Male" <?php if($edit['gender']=='Male'){echo 'checked';} ?>>  
                 Female <input type="radio" name="gender" value="Female" <?php if($edit['gender']=='Female'){echo 'checked';} ?>> </td>
        </tr>
	<tr>
            <td> Contact: </td>
            <td> <input type="text" name="contact" value="<?php if($e){echo $edit['contact'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Email: </td>
            <td> <input type="text" name="email" value="<?php if($e){echo $edit['email'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Address: </td>
            <td> <textarea cols="20" rows="5" name="address"><?php if($e){echo $edit['address'];}else{echo "";}?></textarea> </td>
	</tr>
        <tr>
            <td> School: </td>
            <td> <Select name="school" value="<?php if($e){echo $edit['school'];}else{echo "";}?>">
	                 <option value ="0">Select</option>
	                 <option value ="IT">IT</option>
	                 <option value ="Business">Business</option>
	                 <option value ="Law">Law</option>
                </select> 
          </td>
	</tr>
	<tr>
           <td> Program: </td>
           <td> <Select name="program" value="<?php if($e){echo $edit['program'];}else{echo "";}?>">
	                <option value = "0"> Select </option>
                        <option value = "nD in IT"> nD in IT </option>
                        <option value = "HnD in IT"> HnD in IT </option>
                        <option value = "nD in Business"> nD in Business</option>
                        <option value = "HnD in Business"> HnD in Business </option>
                        <option value = "nD in LAW"> nD in LAW </option>
                        <option value = "HnD in LAW"> HnD in LAW </option>
                   </select> 
             </td>
	</tr>
	<tr>
           <td colspan= "2" align= "right"> <input type= "submit" name="action" value="<?php if($e){echo"Edit Student";}else{echo"Add Student";}?>"> </td>
         </td>
	</tr>
    </table>
  </form>
 <table border="1" width= "600" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "20" align= "center"> Student </td> </tr>
   <tr> <td align="center"> SL No </td> <td align="center"> Name </td> <td align="center"> User ID </td> <td align="center"> Gender </td> <td align="center"> Contact </td> <td align="center"> Email </td> <td align="center"> Address </td> <td align="center"> School </td> <td align="center"> Program </td></tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from user where user_type='student'");
   while($user=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td> <?php echo $i;?></td>
   <td> <?php echo $user['name']; ?> </td>
   <td> <?php echo $user['user_id']; ?> </td>
   <td> <?php echo $user['gender']; ?> </td>
   <td> <?php echo $user['contact']; ?> </td>
   <td> <?php echo $user['email']; ?> </td>
   <td> <?php echo $user['address']; ?> </td>
   <td> <?php echo $user['school']; ?> </td>
   <td> <?php echo $user['program']; ?> </td>
   <td> <a href= "add_student.php?id=<?php echo $user['id'];?>"> Edit </a> </td>
  <td>
  <?php
   echo"<a href=\"javascript:delete_user(id=$user[id])\"> Delete </a>";
   ?>
 </td>  
 </tr>
 
  <?php $i++;} ?>
 
 </table>
<script>
	function validateForm(){
		var name = document.add_student.name.value;
		var user_id = document.add_student.user_id.value;
		var password = document.add_student.password.value;
		var confirm_password = document.add_student.confirm_password.value;
		var gender = document.add_student.gender.value;
		var contact = document.add_student.contact.value;
		var email = document.add_student.email.value;
		var address = document.add_student.address.value;
		var school = document.add_student.school.value;
		var program = document.add_student.program.value;

	if(name==""){alert("Please enter your name."); return false;}
	if(user_id==""){alert("Please enter your User ID."); return false;}
	if(password==""){alert("Please enter your password."); return false;}
	if(confirm_password==""){alert("Please confirm your password."); return false;}
	if(password!=confirm_password){alert("Password does not match."); return false;}
	if(gender==""){alert("Please indentify your gender."); return false;}
	if(contact==""){alert("Please enter your contact."); return false;}
	if(email==""){alert("Please enter your email."); return false;}
	if(address==""){alert("Please enter your address."); return false;}
	if(school==""){alert("Please select your school."); return false;}
	if(program==""){alert("Please choose your program."); return false;}
						}
</script>
  <script language="Javascript">
   function delete_user(id){
              var msg= confirm('Are you sure you want to delete this student?');
            if (msg){
                 window.location="add_student.php?did="+id;  
                }   
           }
 </script>
   </div>
     </body>
</html>

  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>