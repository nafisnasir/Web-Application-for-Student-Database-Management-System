-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2016 at 11:03 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sdbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact_admin`
--

CREATE TABLE IF NOT EXISTS `contact_admin` (
  `name` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_admin`
--

INSERT INTO `contact_admin` (`name`, `contact`, `email`, `description`) VALUES
('Faruk', '01822884858', 'nafis_nasir533@yahoo.com', ''),
('nafis nasir', '01822884858', 'nafis_nasir533@yahoo.com', ''),
('Faruk', '01822884858', 'fatima6n@hotmail.com', 'gdfhgdfghdf df gdfgh df'),
('', '', '', ''),
('nafis nasir', '01822884858', 'nafis_nasir533@yahoo.com', 'dsgdfhb rf df hgfh '),
('Niloy', '123549565', 'ghghbgbnn@yahoo.cpm', 'please do the work'),
('gbngnbg', 'gngn', 'nn', ''),
('salman', '144522', 'b vcbbv@gmail.com', ' ');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE IF NOT EXISTS `notice` (
  `nid` int(11) NOT NULL,
  `title` text NOT NULL,
  `date` varchar(15) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`nid`, `title`, `date`, `description`) VALUES
(9, 'routine', '01/03/2016', 'bfggd gbmm'),
(10, 'seminar', '01/03/2016', 'bvc bl;kjjjjjhhhhhhhhhhhhhhhhhhhhhh'),
(11, 'gaming', '01/03/2016', 'fbvbfgb'),
(12, 'cleaning', '01/03/2016', 'fsdfvdvv');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `user_id` varchar(15) NOT NULL,
  `password` varchar(30) NOT NULL,
  `user_type` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` text NOT NULL,
  `contact` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `school` text NOT NULL,
  `program` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `user_id`, `password`, `user_type`, `email`, `gender`, `contact`, `address`, `school`, `program`) VALUES
(2, 'Superadmin', 'admin', '123', 'admin', '', '', 0, '', '', ''),
(7, 'nafis nasir', 'nafis', '12345', 'student', 'gfdbn k!@gmail.com', 'Male', 1354855255, 'mirpur', 'IT', 'nD in IT'),
(8, 'Ferdous Khan', 'ferdous', '1234', 'faculty', 'bajknkn@hotmail.com', 'Male', 1922884858, 'Mohampur', 'Business', ''),
(9, ' Nadia khan', 'nadia', '123456', 'faculty', 'gdfs@gmail.com', 'Female', 1722884858, 'mirpur', 'IT', ''),
(10, ' Nadia khan', 'nadia', '123456', 'faculty', 'gdfs@gmail.com', 'Female', 1722884858, 'mirpur', 'IT', ''),
(11, 'Golam', 'golam123', '123', 'student', 'nafis_nasir533@yahoo.com', 'Male', 1822884858, 'Dhaka', 'IT', 'nD in IT'),
(12, 'Noloy', 'Noloy', '123', 'student', 'nafis_nasir533@yahoo.com', 'Female', 1822884858, 'Rajshai', 'IT', 'nD in IT'),
(13, 'yhfgh', 'fghgh', '123', 'student', 'fgdgf@gmail.com', 'Male', 234355, 'Dhaka', 'Business', 'nD in Business'),
(14, 'Niloy', 'nafis', '123', 'admin', 'alisharaf895@outlook.com', 'Male', 1822884858, 'Dhaha', '', ''),
(15, 'Faruk', 'nafis1', '123', 'admin', 'fatima6n@hotmail.com', 'Male', 1354855255, 'Hi', '', ''),
(16, 'Faruk', 'nafis111', '123', 'faculty', 'nasir.khan.nnk22@gmail.com', 'Male', 1822884858, 'Raj', 'IT', ''),
(17, 'arnob', 'arnob', '123', 'faculty', 'fatima6n@hotmail.com', 'Male', 1354855255, 'fggbb', 'Business', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
