
<?php

if(isset($_POST['submit'])) {
    if(isset($_POST['email'])) {
        if(isset($_POST['message'])) {

            mysql_query("INSERT INTO Messages (ReturnText, MessageText, SubjectText, TimeText, TypeText) 
            VALUES('$_POST[mobile]', '$_POST[message]', '$_POST[subject]', '354564576754', 'Text') ") or die(mysql_error());
            
            mail("***********@tomomail.com", "SMS", $_POST['message']);

            echo '
            <font color="Green">text message successfully sent.</font>
            ';
            
        } else {
            $err .= "<li>you didn't enter a message.</li>";
        }
        $err .= "<li>you didn't enter your mobile number.</li>";
    }
}

?>
<html>
<head>
    <title>.::. joshshor.net .::. contact</title>
    <meta name="description" content="Everything you want to know about moi! =)">
    <meta name="keywords" content="Josh Shor, Life, blog, photos, projects">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="images/favicon.ico">
    <script type="text/javascript" src="js/pngfix.js"></script>
    <script type="text/javascript" src="js/aimapi.js"></script>
</head>
<body>

<script type="text/javascript">
function chgToMail() {
    document.getElementById('field').innerHTML = 'email:';
    document.getElementById('subject').style.visibility = 'visible';
}

function chgToText() {
    document.getElementById('field').innerHTML = 'mobile #';
    document.getElementById('subject').style.visibility = 'hidden';
}
</script>

<table align="center" cellspacing="0" cellpadding="0" width="650">
    <tr>
        <td style="background: url(images/tree.png) no-repeat; height: 120px; vertical-align: bottom" align="right">
        <div id="tab">
        <ul>
            <li><a href="index.php">home</a></li>
            <li><a href="blog.php">blog</a></li>
            <li><a href="photos.php">photos</a></li>
            <li><a href="contact.php" id="selected">contact</a></li>
        </ul>
        </div>
        </td>
    </tr>
    <tr>
        <td style="border-bottom: 1px dotted white; padding: 3px 3px 3px 3px">
        <font size="5" color="white">contact</font>
        </td>
    </tr>
    <tr>
        <td>
        </td>
    </tr>
</table>

<table width="650" align="center">
    <tr>
        <td>
            <input type="radio" name="type" id="email" checked="checked" onclick="chgToMail()"><label for="email" onclick="chgToMail()">send me an email; if i'm away, i'll read it in a few.</label><br>
            <input type="radio" name="type" id="txtMsg" onclick="chgToText()"><label for="txtMsg" onclick="chgToText()">send me a text message; i'll read it right away.</label>
        </td>
        <td>
            <table align="right">
                <tr>
                    <td align="right">aim:</td>
                    <td>
                    <a href="aim:goim?screenname=joshisshor">joshisshor</a> 
                    <img id="myAwayMessage" class="AIMPresenceWidget joshisshor" alt="" src="images/online.png" title="">
                    </td>
                </tr>
                <tr>
                    <td align="right">facebook:</td>
                    <td><a href="http://www.facebook.com/JShor?ref=name" target="_blank">facebook.com/JShor</a></td>
                </tr>
                <tr>
                    <td align="right">myspace:</td>
                    <td><a href="http://www.myspace.com/josh_shor" target="_blank">myspace.com/josh_shor</a></td>
                </tr>
            </table>
        </td>
    </tr>
</table>

<table align="center" width="650" style="padding-top: 10px">
    <tr id="subject">
        <td align="right"><label for="subj">subject:</label></td>
        <td><input type="text" name="subject" style="width: 580px; background: #ffffe0" id="subj"></td>
    </tr>
    <tr>
        <td align="right"><label for="mail" id="field">email:</label></td>
        <td><input type="email" name="subject" style="width: 580px; background: #ffffe0" id="mail"></td>
    </tr>
    <tr>
        <td align="right" valign="top"><label for="msg">message:</label></td>
        <td><textarea name="message" style="width: 580px; height: 200px; background: #ffffe0" id="msg"></textarea></td>
    </tr>
</table>

<p align="center">
    <input type="submit" name="submit" value="send" class="button">
    &nbsp;
    <input type="reset" value="reset" class="button">
</p>

<p align="center" style="padding-top: 20px">
    <span style="font-size: 8pt; font-family: Georgia; color: #c0c0c0">&copy; 2009 Josh Shor.</font>
</p>

</body>
</html>



