<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from user where id='$did'");
            header("Location:add_admin.php");
             }
?> 

<html>
  <head>
    <style>
   body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 0px black solid;
                 height: 420px; width: 410px;
                }
   .center {
    margin: auto;
    }
         </style>
  </head>


<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>
<body bgcolor="mintcream">
<img src="images/contact.jpg" width="1400" height="250">
<body>

      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_faculty.php">Add Faculty </a>
         </td>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

     </tr>
</table>
</body>



<body bgcolor="brown">
    <body>
<marquee><font size="12"face="italic"color="white">Please fill the requirements</marquee>

   <div class="center">

    <?php if($e){$_SESSION['edit']=$e;
                 $n=mysql_query("select * from user where id='$e'");
                 $edit=mysql_fetch_array($n);}
    ?>
      
 <form action="action.php" method="post" name="add_admin" onsubmit="return(validateForm());">
<?php
if ($_SESSION['msg'])
    {
     echo $_SESSION['msg'];
     $_SESSION['msg']="";
     } 
?>
   <table border="0" width= "410" height= "410" align= "center">
	<tr>
          <td colspan= "2" align= "center" style= "background-color: peachpuff"> <h1> Contact Admin </h1> </td>
	</tr>
	<tr>
           <td> Name: </td>
           <td> <input type="text" name="name" value="" required> </td>
	</tr>
	
	<tr>
            <td> Contact: </td>
            <td> <input type="text" name="contact" value="" required> </td>
	</tr>
	<tr>
            <td> Email: </td>
            <td> <input type="text" name="email" value="" required> </td>
	</tr>
	<tr>
            <td> Message: </td>
            <td> <textarea cols="20" rows="5" name="description" type="text" value="" required></textarea> </td>
	</tr>
       	<tr>
           <td colspan= "2" align= "right"> <input type= "submit" name="action" value="Send Message"> </td>
         </td>
	</tr>
    </table>
  </form>
 


<script>
	function validateForm(){var name = document.add_admin.name.value;
		var user_id = document.add_admin.user_id.value;
		var password = document.add_admin.password.value;
		var confirm_password = document.add_admin.confirm_password.value;
		var gender = document.add_admin.gender.value;
		var contact = document.add_admin.contact.value;
		var email = document.add_admin.email.value;
		var address = document.add_admin.address.value;

	if(name==""){alert("Please enter your name."); return false;}
	if(user_id==""){alert("Please enter your User ID."); return false;}
	if(password==""){alert("Please enter your password."); return false;}
	if(confirm_password==""){alert("Please confirm your password."); return false;}
	if(password!=confirm_password){alert("Password does not match."); return false;}
	if(gender==""){alert("Please indentify your gender."); return false;}
	if(contact==""){alert("Please enter your contact."); return false;}
	if(email==""){alert("Please enter your email."); return false;}
	if(address==""){alert("Please enter your address."); return false;}
						}
</script>
 <script language="Javascript">
   function delete_user(id){
              var msg= confirm('Are you sure you want to delete this admin?');
            if (msg){
                 window.location="add_student.php?did="+id;  
                }   
           }
 </script>
   </div>
     </body>
</html>

  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>