<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from notice where nid='$did'");
            header("Location:add_notice.php");
             }
?> 

<html>
  <head>
    <style>
  li {
    display: inline;
     }
    body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 3px black solid;
                 height: 240px; width: 400px;
                }
 .center {
    margin: auto;
    }
         </style>
  </head>

<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>
<body bgcolor="aliceblue">
<img src="images/university.jpg" width="1400" height="300">

<body>

      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_faculty.php">Add Faculty </a>
         </td>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

		<td class="menu">
            <a class="linkk" href="contact_admin.php">Contact Admin </a>
         </td>

     </tr>
</table>
</body>


<body bgcolor="orange">
    <body>
<marquee><font size="12"face="italic"color="red">NOTICE!!!!!!</marquee>
   <div class="center">
    <?php if($e){$_SESSION['edit']=$e;
                 $n=mysql_query("select * from notice where nid='$e'");
                 $edit=mysql_fetch_array($n);}
    ?>
      
 <form action="action.php" method="post" name="add_notice" onsubmit="return(validateForm());">
<?php
if ($_SESSION['msg'])
    {
     echo $_SESSION['msg'];
     $_SESSION['msg']="";
     } 
?>
   <table border="0" width= "400" height= "200" align= "center">
	<tr>
          <td colspan= "2" align= "center" style= "background-color: Aqua"> <h1> Add Notice </h1> </td>
	</tr>
	<tr>
           <td> Title: </td>
           <td> <input type="text" name="title" value="<?php if($e){echo $edit['title'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
           <td> Date: </td>
           <td> <?php if($e){echo $edit['date'];} else{echo date('d/m/Y');}?> </td>
	</tr>
	<tr>
            <td> Description: </td>
            <td> <textarea cols="20" rows="5" name="description"><?php if($e){echo $edit['description'];}else{echo "";}?></textarea> </td>
	</tr>
	<tr>
           <td colspan= "2" align= "right"> <input type= "submit" name="action" value="<?php if($e){echo"Edit Notice";}else{echo"Add Notice";}?>"> </td>
         </td>
	</tr>
       </body>
      </table>
  </form>
  
 <table border="1" width= "500" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "8" align= "center"> Notice </td> </tr>
   <tr> <td align="center"> SL No </td> <td align="center"> Title </td> <td align="center"> Date </td> <td align="center"> Description </td></tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from notice");
   while($notice=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td> <?php echo $i;?></td>
   <td> <?php echo $notice['title']; ?> </td>
   <td> <?php echo $notice['date']; ?> </td>
   <td> <?php echo $notice['description']; ?> </td>
   <td> <a href= "add_notice.php?id=<?php echo $notice['nid'];?>"> Edit </a> </td>
  <td>
  <?php
   echo"<a href=\"javascript:delete_notice(id=$notice[nid])\"> Delete </a>";
   ?>
 </td>  
 </tr>
 
  <?php $i++;} ?>
 
 </table>
  <script>
	function validateForm(){
		var title = document.add_notice.title.value;
		var description = document.add_notice.description.value;
		
	if(title==""){alert("Please enter the title."); return false;}
	if(description==""){alert("Please enter the description."); return false;}
						}
</script>
 <script language="Javascript">
   function delete_notice(id){
              var msg= confirm('Are you sure you want to delete this notice?');
            if (msg){
                 window.location="add_notice.php?did="+id;  
                }   
           }
 </script>
   </div>
     </body>

  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>