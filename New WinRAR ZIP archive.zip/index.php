<html>
<head>
<Style>
     body{ font-size:14px;
        font-family:Arial;
          }
       div {border:2px blue solid ;
             width:300px; height:200px;
            }
 .center {
    margin: auto;
    }
     </Style>
</head>

<body bgcolor="white">
	<body>
<marquee behaviour="alternative" direction="right"><font size="12"face="italic"color="orange">WELCOME TO BAC INTERNATIONAL</marquee>
<img src="images/Login.png" width="1400" height="300">

 <div class="center">

<div>
	<form action="action.php" method="post" name="index" onsubmit="return(validateForm());">
	<table  border="0" width="300" height="200" align="center">
	<tr>
		<td colspan="3" align="center" style="background-color:Purple"> Login  </td>

	</tr>
<tr>
		<td colspan="2"> <?php
					error_reporting(E_ALL^E_NOTICE);
					session_start();
					if($_SESSION['msg']){
					echo $_SESSION['msg'];
    					$_SESSION['msg']="";} 
			?> 
</td>

	</tr>


	<tr>
		<td>  User ID  </td>
		<td>  <input type="text" name="user_id">  </td>

	</tr>

	<tr>
		<td>  Password  </td>
		<td>  <input type="password" name="password"> </td>

	</tr>

	<tr>
		
		<td colspan="2" align="right"> <input type="Submit" value="Login" name="action">  </td>

	</tr>

	</table>
	</form>
<script>
function validateForm(){
var user_id  = document.index.user_id.value;
var password = document.index.password.value;




if(user_id==""){alert("Please enter your user_id.");return false;}
if(password==""){alert("Please enter your password.");return false;}}
</script>
</div>
	</body>

</html>