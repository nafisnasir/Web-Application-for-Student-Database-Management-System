<?php
	session_start();
	$_SESSION['id']="";
	$_SESSION['name']="";
	$_SESSION['user_id']="";
	$_SESSION['password']="";
	$_SESSION['user_type']="";
	header("Location:index.php");
?>

<marquee><font size="12"face="italic"color="red">Thanks for stopping by!
We hope to see you again soon.</marquee>