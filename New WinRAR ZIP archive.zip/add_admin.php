<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from user where id='$did'");
            header("Location:add_admin.php");
             }
?> 

<html>
  <head>
    <style>
   body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 0px black solid;
                 height: 420px; width: 410px;
                }
   .center {
    margin: auto;
    }
         </style>
  </head>

<body bgcolor="azure">
    <body>
<marquee><font size="12"face="italic"color="white">Please fill the Form to get Access</marquee>
<img src="images/admins.png" width="1300" height="250">
   <div class="center">

    <?php if($e){$_SESSION['edit']=$e;
                 $n=mysql_query("select * from user where id='$e'");
                 $edit=mysql_fetch_array($n);}
    ?>
      
 <form action="action.php" method="post" name="add_admin" onsubmit="return(validateForm());">
<?php
if ($_SESSION['msg'])
    {
     echo $_SESSION['msg'];
     $_SESSION['msg']="";
     } 
?>
   <table border="0" width= "410" height= "410" align= "center">
	<tr>
          <td colspan= "2" align= "center" style= "background-color: grey"> <h1> Add Admin </h1> </td>
	</tr>
	<tr>
           <td> Name: </td>
           <td> <input type="text" name="name" value="<?php if($e){echo $edit['name'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
           <td> User ID: </td>
           <td> <input type="text" name="user_id" value="<?php if($e){echo $edit['user_id'];}else{echo "";}?>"> </td>
	</tr>
        <tr>
           <td> Password: </td>
           <td> <input type="password" name="password" value="<?php if($e){echo $edit['password'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
           <td> Confirm Password: </td>
           <td> <input type="password" name="confirm_password" value="<?php if($e){echo $edit['confirm_password'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Gender: </td>
            <td> Male<input type="radio" name="gender" value="Male" <?php if($edit['gender']=='Male'){echo 'checked';} ?>>  
                 Female <input type="radio" name="gender" value="Female" <?php if($edit['gender']=='Female'){echo 'checked';} ?>> </td>
        </tr>
	<tr>
            <td> Contact: </td>
            <td> <input type="text" name="contact" value="<?php if($e){echo $edit['contact'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Email: </td>
            <td> <input type="text" name="email" value="<?php if($e){echo $edit['email'];}else{echo "";}?>"> </td>
	</tr>
	<tr>
            <td> Address: </td>
            <td> <textarea cols="20" rows="5" name="address"><?php if($e){echo $edit['address'];}else{echo "";}?></textarea> </td>
	</tr>
       	<tr>
           <td colspan= "2" align= "right"> <input type= "submit" name="action" value="<?php if($e){echo"Edit Admin";}else{echo"Add Admin";}?>"> </td>
         </td>
	</tr>
    </table>
  </form>
 <table border="1" width= "700" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "20" align= "center" style="background-color: white"> Admin </td> </tr>
   <tr> <td align="center"> SL No </td> <td align="center"> Name </td> <td align="center"> User ID </td> <td align="center"> Gender </td> <td align="center"> Contact </td> <td align="center"> Email </td> <td align="center"> Address </td></tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from user where user_type='admin'");
   while($user=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td> <?php echo $i;?></td>
   <td> <?php echo $user['name']; ?> </td>
   <td> <?php echo $user['user_id']; ?> </td>
   <td> <?php echo $user['gender']; ?> </td>
   <td> <?php echo $user['contact']; ?> </td>
   <td> <?php echo $user['email']; ?> </td>
   <td> <?php echo $user['address']; ?> </td>
   <td> <a href= "add_admin.php?id=<?php echo $user['id'];?>"> Edit </a> </td>
  <td>
  <?php
   echo"<a href=\"javascript:delete_user(id=$user[id])\"> Delete </a>";
   ?>
 </td>  
 </tr>
 
  <?php $i++;} ?>
 
 </table>
<script>
	function validateForm(){var name = document.add_admin.name.value;
		var user_id = document.add_admin.user_id.value;
		var password = document.add_admin.password.value;
		var confirm_password = document.add_admin.confirm_password.value;
		var gender = document.add_admin.gender.value;
		var contact = document.add_admin.contact.value;
		var email = document.add_admin.email.value;
		var address = document.add_admin.address.value;

	if(name==""){alert("Please enter your name."); return false;}
	if(user_id==""){alert("Please enter your User ID."); return false;}
	if(password==""){alert("Please enter your password."); return false;}
	if(confirm_password==""){alert("Please confirm your password."); return false;}
	if(password!=confirm_password){alert("Password does not match."); return false;}
	if(gender==""){alert("Please indentify your gender."); return false;}
	if(contact==""){alert("Please enter your contact."); return false;}
	if(email==""){alert("Please enter your email."); return false;}
	if(address==""){alert("Please enter your address."); return false;}
						}
</script>
 <script language="Javascript">
   function delete_user(id){
              var msg= confirm('Are you sure you want to delete this admin?');
            if (msg){
                 window.location="add_student.php?did="+id;  
                }   
           }
 </script>
   </div>
     </body>
</html>

  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>