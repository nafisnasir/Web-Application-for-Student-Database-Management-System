<?php
include("dbconnect.php");
session_start();
 if($_SESSION['user_id']!="" and $_SESSION['password']!=""){ 
 if($_SESSION[user_type]=='admin'){
?> 
<html>
  <head>
    <style>
    body{
          font-size:15px;
          font-family:ariel;
         }
           div {border: 3px black solid;
                 height: 370px; width: 400px;
                }
 .center {
    margin: auto;
    }
         </style>
  </head>


<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>
<body bgcolor="blanchedalmond">
<img src="images/faculty-header.jpg" width="1340" height="280">
<body>

      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

		<td class="menu">
            <a class="linkk" href="contact_admin.php">Contact Admin </a>
         </td>

     </tr>
</table>
</body>



<body bgcolor="green">
    <body>

<div class="center">
 <form action="action.php" method="post" name="add_faculty" onsubmit="return(validateForm());">
   <table border="0" width= "400" heigth= "200" align= "center">
	<tr>
          <td colspan= "2" align= "center" style= "background-color: white"> <h1> Add Faculty </h1> </td>
	</tr>
	<tr>
           <td> Name: </td>
           <td> <input type="text" name="name"> </td> 
	</tr>
	<tr>
           <td> User ID: </td>
           <td> <input type="text" name="user_id"> </td>
	</tr>
	<tr>
           <td> Password: </td>
           <td> <input type="password" name="password"> </td>
	</tr>
	<tr>
           <td> Confirm Password: </td>
           <td> <input type="password" name="confirm_password"> </td>
	</tr>
	<tr>
            <td> Gender: </td>
            <td> Male<input type="radio" name="gender" value="Male"> 
                 Female <input type="radio" name="gender" value="Female"> </td>
        </tr>
	<tr>
            <td> Contact: </td>
            <td> <input type="text" name="contact"> </td>
	</tr>
	<tr>
            <td> Email: </td>
            <td> <input type="text" name="email"> </td>
	</tr>
	<tr>
            <td> Address: </td>
            <td> <textarea cols="22" rows="5" name="address"></textarea> </td>
	</tr>
	<tr>
            <td> School: </td>
            <td> <Select name="school">
	                 <option value ="0">Select</option>
	                 <option value ="IT">IT</option>
	                 <option value ="Business">Business</option>
	                 <option value ="Law">Law</option>
                </select> 
          </td>
	</tr>
	<tr>
           <td colspan= "2" align= "right"> <input type= "submit" value= "Add Faculty" name="action"> </td>
         </td>
	</tr>
    </table>
  </form>



<table border="1" width= "600" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "20" align= "center" style="background-color:	oldlace"> Faculty </td> </tr>
   <tr> <td align="center"> SL No </td> <td align="center"> Name </td> <td align="center"> User ID </td> <td align="center"> Gender </td> <td align="center"> Contact </td> <td align="center"> Email </td> <td align="center"> Address </td> <td align="center"> School </td> </tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from user where user_type='faculty'");
   while($user=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td> <?php echo $i;?></td>
   <td> <?php echo $user['name']; ?> </td>
   <td> <?php echo $user['user_id']; ?> </td>
   <td> <?php echo $user['gender']; ?> </td>
   <td> <?php echo $user['contact']; ?> </td>
   <td> <?php echo $user['email']; ?> </td>
   <td> <?php echo $user['address']; ?> </td>
   <td> <?php echo $user['school']; ?> </td>
   <td> <a href= "add_faculty.php?id=<?php echo $user['id'];?>"> Edit </a> </td>
  <td>
  <?php
   echo"<a href=\"javascript:delete_user(id=$user[id])\"> Delete </a>";
   ?>
 </td>  
 </tr>
 
  <?php $i++;} ?>
 
 </table>

<script>
	function validateForm(){
		var name = document.add_faculty.name.value;
		var user_id = document.add_faculty.user_id.value;
		var password = document.add_faculty.password.value;
		var confirm_password = document.add_faculty.confirm_password.value;
		var gender = document.add_faculty.gender.value;
		var contact = document.add_faculty.contact.value;
		var email = document.add_faculty.email.value;
		var address = document.add_faculty.address.value;
		var school = document.add_faculty.school.value;
		
	if(name==""){alert("Please enter your name."); return false;}
	if(user_id==""){alert("Please enter your User ID."); return false;}
	if(password==""){alert("Please enter your password."); return false;}
	if(confirm_password==""){alert("Please confirm your password."); return false;}
	if(password!=confirm_password){alert("Password does not match."); return false;}
	if(gender==""){alert("Please indentify your gender."); return false;}
	if(contact==""){alert("Please enter your contact."); return false;}
	if(email==""){alert("Please enter your email."); return false;}
	if(address==""){alert("Please enter your address."); return false;}
	if(school==""){alert("Please select your school."); return false;}
				}
   </script>
   </div>
     </body>
</html>
 
  <?php
     }
 else
  {
    $_SESSION[msg]= "You are not authorized to access this page";
     header("Location:logout.php");
    }
  }
 else
  {
    $_SESSION[msg]= "You have to login first";
    header("Location:index.php");
  }
?>
