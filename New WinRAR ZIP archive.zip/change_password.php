
<?php

session_start();
include("dbconnect.php");
if($_SESSION['user_id']!="" and $_SESSION['password']!=""){

?>

  <html>
<head>
<Style>
body{ font-size:14px;
font-family:Arial;}
div {border:0px blue solid ;
width:530px; 
height:150px;}
 .center {
    margin: auto;
    }
</Style>


<?php 


	if($_SESSION['msg'])
	{
	echo $_SESSION['msg']; 
	$_SESSION['msg']="";
}
?>
<body bgcolor="	azure">
<body>

<img src="images/change password.png" width="1400" height="400">
<div class="center">

   
	<form action="action.php" name="change_password" method="post">  



	<table  border="0" width="480" height="150" align="center">

	<tr>
		<td colspan="2" align="center" style="background-color:Yellow"> Change Password  </td>
	</tr>

	<tr>	
	<td> Current Password </td>
	<td> <input type="password" name="current_p"> </td>
	</tr>
         
	<tr>	       
	<td> New Password </td>
	<td>  <input type="password" name="new_p"> </td>
	</tr>
	 
	<tr>
	<td> Confirm Password </td>
	<td> <input type="password" name="confirm_p"> </td>
	</tr>

       	<tr>	
	<td colspan="2" align="center"> <input type="submit" name="action" value="Change Password"> </td>
	</tr>


	</form>
</body>
</div>
   </html>
</head>

<?php
}

		else{
				$_SESSION['msg']="You are not registered";
						header("Location:index.php");

						}
?>