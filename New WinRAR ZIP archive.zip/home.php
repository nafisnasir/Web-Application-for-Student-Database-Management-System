<?php
include("dbconnect.php");
session_start();
if($_SESSION['user_id']!="" and $_SESSION['password']!=""){
  if($_GET['id']!="") 
   {
    $e= $_GET['id'];
    }
  $did= $_GET['did'];
  if($did) {
            mysql_query("delete from notice where nid='$did'");
            header("Location:add_notice.php");
             }
            
?>


<html>
<head>
  <style>
     body{background color:#999;}
    .menu{
         background-color:darkgray;
         padding-left:20px;
         padding-right:20px;
         font:family:tahoma;
         font-size:19px;
         font-weigh:bold;
         cursor:pointer;
         }
a.linkk:link{color:black;text-decoration:none;}
a.linkk:visited{color:black;}
a.linkk:hover{color:red;}
.menu:hover{background-color:black;}
</style>
 </head>

<body bgcolor="orange">
<img src="images/university.jpg" width="1400" height="300">
<body>


      <table border="1" align="center" cellspacing="10">
       <tr>
         <td class="menu">
            <a class="linkk" href="home.php">Home </a>
         </td>
          <td class="menu">
            <a class="linkk" href="add_student.php">Add Student </a>
         </td>
          <td class="menu">
            <a class="linkk" href="logout.php">Logout </a>
         </td>
	<td class="menu">
            <a class="linkk" href="change_password.php">change password </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_admin.php">Add Admin </a>
         </td>
	<td class="menu">
            <a class="linkk" href="add_faculty.php">Add Faculty </a>
         </td>
         </td>
	<td class="menu">
            <a class="linkk" href="add_notice.php">Add Notice </a>
         </td>
	<td class="menu">
            <a class="linkk" href="admin_message.php">Admin Message </a>
         </td>

		<td class="menu">
            <a class="linkk" href="contact_admin.php">Contact Admin </a>
         </td>

     </tr>
</table>
</body>



   <table border="2" width= "500" height= "100">
  <br>
  <br>
  <br>
   <tr> <td colspan= "8" align= "center" style="background-color: lightblue"> Notice </td> </tr>
   <tr> <td align="center" style="background-color: white"> Title </td> <td align="center" style="background-color: white"> Date </td> <td align="center" style="background-color: white"> Description </td></tr>
  <?php
   $i=1;
   $sql=mysql_query("select * from notice order by nid desc limit 5");
   while($notice=mysql_fetch_array($sql)){
   ?>
 <tr>
   <td style="background-color: white"> <?php echo $notice['title']; ?> </td>
   <td style="background-color: white"> <?php echo $notice['date']; ?> </td>
   <td style="background-color: white"> <?php echo $notice['description']; ?> </td>
   </td>  
 </tr>


 
  <?php $i++;} ?>
 
 </table>
 
 <div class="footer">
      <img src="images/footer.jpg" width="1400" height="200">
    </div>
  </body>
</html>

</html> 

<?php
}
else
{$_SESSION['msg']="You have to login first";
   header("Location:index.php");
}
?>     