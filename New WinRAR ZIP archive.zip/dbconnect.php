<?php
error_reporting(E_ALL^E_NOTICE);
$connect=mysql_connect("localhost","root","");
mysql_select_db("sdbms",$connect);

?>